import { Component, OnInit, ElementRef, ViewChild, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as echarts from 'echarts';
import { EChartsOption } from 'echarts';
import { Subscription } from 'rxjs';
import html2canvas from 'html2canvas';

interface DataItem{
  Month: string;
  'Primary product': number;
  'Secondary product': number;
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})


export class AppComponent implements OnInit, OnDestroy{
  title = 'inventory';
  chartData: DataItem[] = [];
  chartInstance: echarts.ECharts | null = null;
  @ViewChild('chartContainer') chartContainer!: ElementRef;
  private fetchDataSubscription?: Subscription;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchData();
  }

ngOnDestroy(): void {
    if (this.fetchDataSubscription) {
      this.fetchDataSubscription.unsubscribe();
    }
    if (this.chartInstance) {
      this.chartInstance.dispose();
    }
  }

  fetchData(): void {
    this.fetchDataSubscription = this.http.get<DataItem[]>('http://localhost:8081/api/data').subscribe(
      (data) => {
        this.chartData = data;
        this.renderChart();
      },
      (error) => {
        console.error('Error fetching data:', error);
      }
    );
  }

  renderChart(): void {
    if (!this.chartContainer) {
      return;
    }

    const chartDom = this.chartContainer.nativeElement;
    this.chartInstance = echarts.init(chartDom);

    let month = this.chartData.map(item => item.Month)
    let primary =this.chartData.map(item => item['Primary product'])
    let secondary =this.chartData.map(item => item['Secondary product'])

    const option: EChartsOption = {
      xAxis: {
        type: 'category',
        data: month
      },
      yAxis: {
        type: 'value'
      },
      series: [
        {
          name: 'Primary product',
          type: 'bar',
          data: primary
        },
        {
          name: 'Secondary product',
          type: 'bar',
          data: secondary
        }
      ],
      legend: {
        data: ['Primary product', 'Secondary product']
      }
    };

    option && this.chartInstance.setOption(option);
  }


 downloadExcel(): void {
    window.open('http://localhost:8081/api/download/excel');
  }

async downloadPdf(): Promise<void> {
    try {
      const { jsPDF } = await import('jspdf');
      const html2canvasModule = await import('html2canvas');
      const html2canvas = html2canvasModule.default; 

      const chartElement = this.chartContainer.nativeElement;
      if (chartElement) {
        html2canvas(chartElement).then((canvas) => {
          const imgData = canvas.toDataURL('image/png');
          const pdf = new jsPDF('landscape');
          const imgProps = pdf.getImageProperties(imgData);
          const pdfWidth = pdf.internal.pageSize.getWidth();
          const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
          pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
          pdf.save('chart.pdf');
        });
      } else {
        console.error('Chart element not found.');
      }
    } catch (error) {
      console.error('Error during PDF download:', error);
    }
  }
}
